<?php
    $servername='localhost';
    $dbname='fas';
    $username='root';
    $password='';

    $mysqli=mysqli_connect($servername,$username,$password,$dbname);
?>